import React, { useState, useEffect } from "react";
import Tabs from "./CAD Product/components/tabs/Tabs"; // Tabs component
import CADCalculator from "./CAD Product/components/modules/CAD/CADCalculator"; // All three modules in ONE folder
import ActivityCalculator from "./CAE Product/ActivityCalculator";
import PSCalculator from "./PS Product/components/modules/PS/PSCalculator";
import { view, invoke } from "@forge/bridge"; // Forge API for modal interaction
import pako from "pako";
import { StorageContext } from "./StorageContext";

export default function App() {
  const [activeTab, setActiveTab] = useState("CAD");
  const [issueData, setIssueData] = useState(null);
  const [storedData, setStoredData] = useState(null);
  const [cadJson, setCadJson] = useState({ activities: {} });

  // const [error, setError] = useState(null);

  console.log("Hello World !!");

  useEffect(() => {
    console.log("Hello Effect 1");

    if (cadJson && cadJson.activities) {
      setStoredData(cadJson);
    }
  }, [cadJson]);

  useEffect(() => {
    loadAllValues();
    console.log("loaded");
  }, []);

  const loadAllValues = async () => {
    const context = await view.getContext();
    const issue = context.extension.issue; // context.issue may contain { key: 'ABC-123', ... }
    console.log(issue);
    const fetchActivities = async () => {
      const fetchedData = await invoke("getQuotationData", { issue });
      const quotIssueData = fetchedData.issueData;
      setIssueData(quotIssueData);
      const base64String = fetchedData.quotationData;
      // console.log("B64 --> ", base64String);
      setCadJson(base64String);
      if (base64String) {
        const uint8Arr = base64ToUint8Array(base64String);
        const decompressedString = pako.inflate(uint8Arr, { to: "string" });
        const parsedData = JSON.parse(decompressedString);
        console.log("Parsed Data: ");
        console.log(parsedData);
        setCadJson(parsedData);
      }
    };
    await fetchActivities();
    // setCreated(false)
    // if (issue && issue.key) {
    //   setIssueKey(issue.key);
    //   // Once we have issueKey, fetch data from storage
    //   const base64String = await invoke('getData', { issueKey: issue.key, phase });
    //   if (base64String) {
    //     const uint8Arr = base64ToUint8Array(base64String);
    //     const decompressedString = pako.inflate(uint8Arr, { to: 'string' });
    //     const parsedData = JSON.parse(decompressedString);

    //     setPhaseName(parsedData.phaseName);
    //     // setExtraWork(parsedData.extraWork);
    //     setMilestones(parsedData.milestones);
    //     setActivities(parsedData.activities);
    //     setTotalHours(parsedData.totalHours);
    //     setCreated(true)
    //   }
    // }
  };

  const handleSave = async (updatedData) => {
    // const blob = new Blob([JSON.stringify({ activities: data ,id:json.id,name:json.name}, null, 2)], {
    //   type: 'application/json',
    // });
    // const url = URL.createObjectURL(blob);
    // const a = document.createElement('a');
    // a.href = url;
    // a.download = 'updated_activities.json';
    // a.click();
    // URL.revokeObjectURL(url);
    const context = await view.getContext();
    const issue = context.extension.issue.key;
    console.log("Handle Save -- > \n", JSON.stringify(updatedData));
    setStoredData(updatedData); // update Global Context
    // let payload = { activities: data, id: json.id, name: json.name };
    let payload = updatedData;
    const jsonString = JSON.stringify(payload);
    const compressedData = pako.deflate(jsonString);
    const base64String = uint8ArrayToBase64(compressedData);
    await invoke("saveQuotationData", { issue, data: base64String });
    console.log("quotation saved");

    // Show selected roof types
    const selectedRoofTypes = [];
    const allRoofTypes = new Set();

    // // Get all unique roof types
    // Object.values(data).forEach((activity) => {
    //   Object.keys(activity).forEach((key) => {
    //     if (!nonProductPartKeys.includes(key)) {
    //       allRoofTypes.add(key);
    //     }
    //   });
    // });

    // // Check which roof types are selected and have quantities
    // Array.from(allRoofTypes).forEach((roofType) => {
    //   const firstActivity = Object.values(data).find(
    //     (activity) => activity[roofType]
    //   );
    //   if (
    //     firstActivity &&
    //     firstActivity[roofType].componentSelected &&
    //     firstActivity[roofType].noOfComponent > 0
    //   ) {
    //     selectedRoofTypes.push(
    //       `${roofType}: ${firstActivity[roofType].noOfComponent}`
    //     );
    //   }
    // });

    // if (selectedRoofTypes.length > 0) {
    //   alert(
    //     `Data saved successfully!\n\nSelected Roof Types (applies to all activities):\n${selectedRoofTypes.join(
    //       "\n"
    //     )}`
    //   );
    // } else {
    //   alert("Data saved successfully!");
    // }
  };

  function uint8ArrayToBase64(uint8Arr) {
    let CHUNK_SIZE = 0x8000;
    let chunks = [];
    for (let i = 0; i < uint8Arr.length; i += CHUNK_SIZE) {
      chunks.push(
        String.fromCharCode.apply(null, uint8Arr.subarray(i, i + CHUNK_SIZE))
      );
    }
    const binaryString = chunks.join("");
    return btoa(binaryString);
  }

  function base64ToUint8Array(base64) {
    const binaryString = atob(base64);
    const length = binaryString.length;
    const bytes = new Uint8Array(length);
    for (let i = 0; i < length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  return (
    <div style={{ padding: 18 }}>
      {/* ================= Sticky Tabs ================= */}
      <StorageContext.Provider value={{ storedData, handleSave, issueData }}>
        <div
          style={{
            position: "sticky",
            top: 0,
            zIndex: 1000,
            background: "#fff",
            borderBottom: "1px solid #ddd",
          }}
        >
          <Tabs active={activeTab} setActive={setActiveTab} />
        </div>

        {/* ================= Content ================= */}
        <div style={{ marginTop: 10 }}>
          {/* {activeTab === "CAD" && <CADCalculator />}
          {activeTab === "CAE" && <ActivityCalculator />}
          {activeTab === "PS" && <PSCalculator />} */}
          <div style={{ display: activeTab === "CAD" ? "block" : "none" }}>
            <CADCalculator />
          </div>

          <div style={{ display: activeTab === "CAE" ? "block" : "none" }}>
            <ActivityCalculator />
          </div>

          <div style={{ display: activeTab === "PS" ? "block" : "none" }}>
            <PSCalculator />
          </div>
        </div>
      </StorageContext.Provider>
    </div>
  );
}
