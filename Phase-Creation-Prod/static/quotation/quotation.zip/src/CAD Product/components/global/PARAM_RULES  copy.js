export const GlOBAL_VARIBALE_PARAM_RULES = {
  // -------------------------
  // GLOBAL METRICS

  // All below first Set(Default) from useActivityLogic.js . If you want to Set options list then use this. If you are not setting option then "GlobalPara.js" will be By Default Consider "YES/No"
  // -------------------------
  TDL: {
    options: ["YES", "NO"],
  },
  COO: {
    options: ["YES", "NO"],
  },
  DE: {
    options: ["YES", "NO"],
  },

  // -------------------------
  // 2D RELATED
  // -------------------------
  // "2D": {
  //   options: ["YES", "NO"],
  // },
  "2d Antolin Drawings": {
    options: ["YES", "NO"],
  },
  "2d Customer Drawings": {
    options: ["YES", "NO"],
  },

  // -------------------------
  // OTHER MODULES
  // -------------------------
  "Data Management": {
    options: ["YES", "NO"],
  },
  "Geometrical Study": {
    options: ["YES", "NO"],
  },

  // -------------------------
  // FEASIBILITY
  // -------------------------
  Feasibility: {
    options: ["YES", "NO", "NA"],
  },

  // -------------------------
  // PRODUCT TYPE
  // -------------------------
  product: {
    options: [
      "Door Panel",
      "Pillars",
      "Headliner",
      "IP",
      "CC",
      "Sunvisor",
      "WR",
      "Lighting",
      "FEC",
      "CIDUT",
    ],
  },
  Customer: {
    options: [
      "Acura",
      "Aiways",
      "Alfa Romeo",
      "Ashok Leyland",
      "Aston Martin",
      "Audi",
      "Bajaj",
      "Bentley",
      "BMW",
      "Buick",
      "Cadillac",
      "Canoo",
      "Chery",
      "Chevrolet",
      "CHJ",
      "Chrysler",
      "Dodge",
      "Evergrande",
      "FAW",
      "Ferrari",
      "Fiat",
      "Fisker",
      "Force Motors",
      "Ford",
      "Foxtron",
      "Fujian",
      "GAZ",
      "Geely",
      "GMC",
      "Günsel",
      "Honda",
      "Hongqi",
      "Hozon",
      "Hyundai",
      "Iconiq",
      "Ineos",
      "Isuzu",
      "Iveco",
      "Jeep",
      "JLR",
      "Karma",
      "KIA",
      "Lada",
      "Lamborghini",
      "Lincoln",
      "Mahindra",
      "MAN",
      "Maserati",
      "Mazda",
      "Mercedes-Benz",
      "MG",
      "Mini",
      "Mitsubishi",
      "NIO",
      "Nissan",
      "Polestar",
      "Porsche",
      "PSA",
      "Qoros",
      "Ram",
      "Renault",
      "Rivian",
      "Rolls Royce",
      "Saab",
      "SAIC",
      "Seat",
      "Skoda",
      "Smart",
      "Sono Motors",
      "Stellantis",
      "Suzuki",
      "Tata",
      "Tesla",
      "TOGG",
      "Toyota",
      "UAZ",
      "Velocity",
      "Vinfast",
      "Volkswagen",
      "Volvo",
      "Webasto",
      "Xiaopeng",
      "Yulon",
      "Zotye",
    ],
  },

  "Type Of Development": {
    options: ["FSS", "BTP"],
  },
};
