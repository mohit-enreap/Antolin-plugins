// components/ActivityTable.jsx
import React from "react";

function ActivityTableLessDetails({ activities, updateActivity }) {
  const grouped = Object.entries(activities).reduce((acc, [key, act]) => {
    const [group, name] = key.split("|");
    if (!acc[group]) acc[group] = [];
    acc[group].push({ key, name, act });
    return acc;
  }, {});

  return (
    <div
      style={{
        background: "#fff",
        padding: "16px",
        borderRadius: "6px",
        marginBottom: "20px",
      }}
    >
      <h2>Activities</h2>

      <table>
        <thead>
          <tr>
            <th>Activity</th>

            <th>Loops</th>
            <th>Select</th>
            <th>Total</th>
            <th>Dyanamic Total</th>
          </tr>
        </thead>

        <tbody>
          {Object.entries(grouped).map(([group, rows]) => (
            <React.Fragment key={group}>
              <tr>
                <td
                  colSpan={11}
                  style={{
                    background: "#0b72d0",
                    color: "#fff",
                    fontWeight: "bold",
                  }}
                >
                  {group}
                </td>
              </tr>

              {rows.map(({ key, name, act }) => (
                <tr key={key}>
                  <td>{name}</td>

                  <td>
                    <input
                      type="number"
                      min="1"
                      value={act.noOfLoops}
                      onChange={(e) =>
                        updateActivity(key, "noOfLoops", +e.target.value)
                      }
                    />
                  </td>

                  <td>
                    <input
                      type="checkbox"
                      checked={act.checked}
                      onChange={(e) =>
                        updateActivity(key, "checked", e.target.checked)
                      }
                    />
                  </td>

                  <td>{act.previewTotal || 0}</td>
                  <td>{act.calculatedTotal || 0}</td>
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ActivityTableLessDetails;
