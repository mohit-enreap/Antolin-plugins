import GlobalParams from "./components/GlobalParams";
import ActivityTable from "./components/ActivityTable";
import ActivityTableLessDetails from "./components/ActivityTableLessDetails";
import ResultTable from "./components/ResultTable";
import JSONViewer from "./components/JSONViewer";
import { useActivityLogic } from "./hooks/useActivityLogic";
import CAESummaryTable from "./components/CAESummaryTable";
import React, { useState } from "react";

function ActivityCalculator() {
  const logic = useActivityLogic();
  const iterationTotal =
    logic.activities["ITERATIONS|ITERATIONS"]?.calculatedTotal || 0;

  const [showActivities, setShowActivities] = useState(false);
  return (
    <>
      <h1>NEW</h1>
      <GlobalParams
        globalTDL={logic.globalTDL}
        globalDE={logic.globalDE}
        setGlobalTDL={logic.setGlobalTDL}
        setGlobalDE={logic.setGlobalDE}
      />

      <ActivityTableLessDetails
        activities={logic.activities}
        updateActivity={logic.updateActivity}
      />

      <button
        onClick={() => setShowActivities((prev) => !prev)}
        style={{ marginBottom: 10 }}
      >
        {showActivities ? "Hide Activities Details" : "Show Activities Details"}
      </button>

      {showActivities && (
        <ActivityTable
          activities={logic.activities}
          updateActivity={logic.updateActivity}
        />
      )}

      <ResultTable
        activities={logic.activities}
        sumTDL={logic.sumTDL}
        sumDE={logic.sumDE}
        grand={logic.grandTotal}
        globalTDL={logic.globalTDL}
        globalDE={logic.globalDE}
      />

      {/* ✅ Small summary table – NO extra logic */}
      <CAESummaryTable
        standard={logic.sumTDL}
        iteration={iterationTotal}
        engineers={logic.sumDE}
      />

      <button onClick={logic.saveTemp}>Temp Save</button>
      <button onClick={logic.saveFinal}>Final Save</button>

      <JSONViewer title="Temp JSON" json={logic.tempJSON} />
      <JSONViewer title="Final JSON" json={logic.finalJSON} />
    </>
  );
}

export default ActivityCalculator;
