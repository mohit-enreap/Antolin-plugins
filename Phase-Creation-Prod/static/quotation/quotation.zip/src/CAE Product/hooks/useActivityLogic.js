// hooks/useActivityLogic.js
import { useState, useMemo } from "react";
import { caeInitialData } from "../data/caeInitialData";
import { useCalculations } from "./useCalculations";

export function useActivityLogic() {
  const [data, setData] = useState(caeInitialData);
  const [globalTDL, setGlobalTDL] = useState(1);
  const [globalDE, setGlobalDE] = useState(1);
  const [tempJSON, setTempJSON] = useState("");
  const [finalJSON, setFinalJSON] = useState("");

  const updateActivity = (key, field, value) => {
    setData((prev) => {
      const copy = JSON.parse(JSON.stringify(prev));
      copy.CAE.activities[key][field] = value;
      return copy;
    });
  };

  // 🧠 Central calculation
  const calculation = useMemo(() => {
    return useCalculations(data.CAE.activities, globalTDL, globalDE);
  }, [data, globalTDL, globalDE]);

  const saveTemp = () => {
    setTempJSON(
      JSON.stringify(
        {
          ...data,
          CAE: {
            ...data.CAE,
            activities: calculation.activities,
          },
        },
        null,
        2
      )
    );
  };

  const saveFinal = () => {
    setFinalJSON(
      JSON.stringify(
        {
          ...data,
          CAE: {
            ...data.CAE,
            activities: calculation.activities,
          },
        },
        null,
        2
      )
    );
  };

  return {
    // data
    data,
    activities: calculation.activities,

    // globals
    globalTDL,
    globalDE,
    setGlobalTDL,
    setGlobalDE,

    // results
    sumTDL: calculation.sumTDL,
    sumDE: calculation.sumDE,
    grandTotal: calculation.grand,

    // actions
    updateActivity,
    saveTemp,
    saveFinal,

    // json
    tempJSON,
    finalJSON,
  };
}
