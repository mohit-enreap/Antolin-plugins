// hooks/useCalculations.js
export function useCalculations(activities, globalTDL, globalDE) {
  let sumTDL = 0;
  let sumDE = 0;
  let grand = 0;

  const result = JSON.parse(JSON.stringify(activities));

  Object.entries(result).forEach(([key, a]) => {
    if (key === "ITERATIONS|ITERATIONS") return;

    // 🔹 PREVIEW TOTAL (always visible)
    a.previewTotal = (a.TDL + a.DE + a.COO) * a.noOfLoops;

    // 🔹 FINAL TOTAL (result table logic)
    const tdl = a.checked ? a.TDL * globalTDL : 0;
    const de = a.checked ? a.DE * globalDE : 0;
    const coo = a.checked ? a.COO : 0;

    const total = (tdl + de + coo) * a.noOfLoops;
    a.calculatedTotal = total;

    sumTDL += tdl;
    sumDE += de;
    grand += total;
  });

  // 🔁 ITERATION LOGIC
  const iter = result["ITERATIONS|ITERATIONS"];
  if (iter?.checked) {
    const iterDE = Object.entries(result)
      .filter(([k, a]) => a.checked && k !== "ITERATIONS|ITERATIONS")
      .reduce((s, [, a]) => s + a.DE * globalDE, 0);

    iter.calculatedTotal =
      ((iterDE * (iter.percentage || 0)) / 100) * iter.noOfLoops;

    grand += iter.calculatedTotal;
  }

  return {
    activities: result,
    sumTDL,
    sumDE,
    grand,
  };
}
