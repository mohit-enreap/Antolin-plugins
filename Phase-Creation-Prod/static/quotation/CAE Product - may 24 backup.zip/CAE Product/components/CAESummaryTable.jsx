// components/CAESummaryTable.jsx
import React from "react";

function CAESummaryTable({ standard, iteration, engineers }) {
  return (
    <div
      style={{
        background: "#fff",
        padding: "16px",
        borderRadius: "6px",
        marginBottom: "20px",
        maxWidth: "400px",
      }}
    >
      <h3>CAE Summary</h3>

      <table>
        <tbody>
          <tr>
            <td>
              <strong>CAE Engineers (i.e CE) (TDL) </strong>
            </td>
            <td>{standard}</td>
          </tr>
          <tr>
            <td>
              <strong>CAE Iteration</strong>
            </td>
            <td>{iteration}</td>
          </tr>
          <tr>
            <td>
              <strong>CAE Standard Work (i.e SOW) (DE)</strong>
              <h6>(Iteration calcualtion based on this)</h6>
            </td>
            <td>{engineers}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default CAESummaryTable;
