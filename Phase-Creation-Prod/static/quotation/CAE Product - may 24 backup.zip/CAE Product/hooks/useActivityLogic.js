// hooks/useActivityLogic.js
import { useState, useMemo, useContext, useEffect } from "react";
import { caeInitialData } from "../data/caeInitialData";
import { useCalculations } from "./useCalculations";
import { StorageContext } from "../../StorageContext";
import { sharedRef } from "../../shared/sharedStore";
import { CAE_SHORTCUT } from "../data/CAE_SHORTCUT";
import { useActivityLogic as useCADActivityLogic } from "../../CAD Product/hooks/useActivityLogic";

import { getCheckedActivities } from "../utils/CAE_Pdf";

export function useActivityLogic() {
  // -------------------------
  // 1️⃣ BASE DATA
  // -------------------------

  const [data, setData] = useState(caeInitialData);

  // -------------------------
  // 2️⃣ GLOBAL PARAMETERS (ON/OFF)
  // -------------------------
  const [globalTDL, setGlobalTDL] = useState(1);
  const [globalDE, setGlobalDE] = useState(1);

  const {
    storedDataCae,
    issueData,
    handleSaveCae,
    selectedVersion,
    currentVersion,
  } = useContext(StorageContext);

  // const cadLogic = useCADActivityLogic();
  // const customerName = cadLogic?.globalParams.Customer;

  //OLD Use Effect
  // useEffect(() => {
  //   if (!storedDataCae) return;

  //   console.log("Hello CAE", storedDataCae);

  //   if (storedDataCae.Global) {
  //     console.log("Hello CAE Effect --> No ShortCut", storedDataCae.Global);

  //     setGlobalTDL(storedDataCae.Global.TDL);
  //     setGlobalDE(storedDataCae.Global.DE);
  //   } else {
  //     setData({
  //       Global: {
  //         TDL: globalTDL,
  //         DE: globalDE,
  //       },
  //       activities: storedDataCae.activities,
  //     });
  //     if (issueData) {
  //       console.log("Hello CAE Effect --> Yes ShortCut", issueData);
  //       const customerName = issueData.customer;
  //       applyShortcutForCustomer(customerName, CAE_SHORTCUT, setData);

  //       return;
  //     }
  //   }

  //   setData({
  //     Global: {
  //       TDL: globalTDL,
  //       DE: globalDE,
  //     },
  //     activities: storedDataCae.activities,
  //   });
  // }, [storedDataCae, issueData]);

  //NEW Use Effect
  useEffect(() => {
    if (!storedDataCae) return;

    console.log("Hello CAE", storedDataCae);

    // ✅ Case 1: Global exists → NO shortcut
    if (storedDataCae.Global) {
      console.log("Hello CAE Effect --> No ShortCut");

      setGlobalTDL(storedDataCae.Global.TDL);
      setGlobalDE(storedDataCae.Global.DE);

      setData({
        Global: storedDataCae.Global,
        activities: storedDataCae.activities,
      });

      return; // ⛔ IMPORTANT → Prevent shortcut execution
    }

    // ✅ Case 2: Global does NOT exist → Apply shortcut

    setData({
      Global: {
        TDL: globalTDL,
        DE: globalDE,
      },
      activities: storedDataCae.activities,
    });

    if (issueData?.customer) {
      console.log("Hello CAE Effect --> Yes ShortCut");

      applyShortcutForCustomer(issueData.customer, CAE_SHORTCUT, setData);
    }
  }, [storedDataCae, issueData]);
  // useEffect(() => {
  //   //Apply shortcut .Short cut should  overide once saved CAE data

  //   if (!customerName) return;

  //   applyShortcutForCustomer(customerName, CAE_SHORTCUT, setData);
  // }, [customerName]);

  // -------------------------
  // 3️⃣ UPDATE ACTIVITY
  // -------------------------
  const updateActivity = (key, field, value) => {
    setData((prev) => {
      const copy = structuredClone(prev);
      copy.activities[key][field] = value;
      return copy;
    });
  };

  // -------------------------
  // 4️⃣ CALCULATION (derived)
  // -------------------------
  const calculation = useMemo(() => {
    if (!data?.activities) return null;

    return useCalculations(data.activities, globalTDL, globalDE);
  }, [data?.activities, globalTDL, globalDE]);

  // -------------------------
  // 5️⃣ GLOBAL OBJECT
  // -------------------------
  const Global = { TDL: globalTDL, DE: globalDE };

  // -------------------------
  // 6️⃣ APPLY GLOBAL RULES (for final JSON)
  // -------------------------
  const applyGlobalRules = (activities, global) => {
    return Object.fromEntries(
      Object.entries(activities).map(([key, activity]) => [
        key,
        {
          ...activity,
          TDL: global.TDL === 1 ? activity.TDL : 0,
          DE: global.DE === 1 ? activity.DE : 0,
        },
      ]),
    );
  };

  // -------------------------
  // 7️⃣ BUILD TEMP JSON (snapshot)
  // -------------------------
  const buildTempJson = () => {
    const finalData = {
      Global,
      activities: applyGlobalRules(calculation.activities, Global),
    };

    //  Append only
    finalData.CAE_PDF_DATA = getCheckedActivities(finalData);

    return finalData;
  };
  // const buildTempJson = () => ({
  //   Global,
  //   activities: calculation.activities,
  // });

  // -------------------------
  // 8️⃣ BUILD FINAL JSON (apply global rules)
  // -------------------------
  const buildFinalJson = () => {
    const finalData = {
      Global,
      activities: applyGlobalRules(calculation.activities, Global),
    };

    // Append only
    finalData.CAE_PDF_DATA = getCheckedActivities(finalData);

    return finalData;
  };
  // const buildFinalJson = () => ({
  //   Global,
  //   activities: applyGlobalRules(calculation.activities, Global),
  // });

  // -------------------------
  // 🔄 AUTO-LOAD CAE DATA TO SHARED REF (without saving)
  // -------------------------
  const autoLoadCaeDataToSharedRef = () => {
    if (!calculation) return;

    const iterationTotal =
      calculation.activities["ITERATIONS|ITERATIONS"]?.calculatedTotal || 0;

    // Calculating Phase 1 & Phase 2 for CAE Engineers (TDL + Iteration)
    const CAEEngineersPhase1Value = (calculation?.sumTDL ?? 0) / 2;
    const CAEEngineersPhase2Value = (calculation?.sumTDL ?? 0) / 2;

    // Calculating Phase 1 & Phase 2 for CAE Standard Work
    const CAEStandardWorkPhase1Value =
      ((calculation?.sumDE ?? 0) + (iterationTotal ?? 0)) / 2;
    const CAEStandardWorkPhase2Value =
      ((calculation?.sumDE ?? 0) + (iterationTotal ?? 0)) / 2;

    // Generate PDF Data
    const finalContextData_pdfData = getCheckedActivities(calculation);

    sharedRef.currentCAE = {
      globalTDL: globalTDL ?? 0,
      globalDE: globalDE ?? 0,

      sumTDL: calculation?.sumTDL ?? 0,
      sumDE: calculation?.sumDE ?? 0,
      grandTotal: calculation?.grand ?? 0,
      activities: calculation?.activities ?? [],

      tempJSON: JSON.stringify(buildTempJson() ?? {}, null, 2),
      finalJSON: JSON.stringify(buildFinalJson() ?? {}, null, 2),

      iterationTotal: iterationTotal ?? 0,

      CAEEngineersPhase1: CAEEngineersPhase1Value,
      CAEEngineersPhase2: CAEEngineersPhase2Value,

      CAEStandardWorkPhase1: CAEStandardWorkPhase1Value,
      CAEStandardWorkPhase2: CAEStandardWorkPhase2Value,

      pdfData: finalContextData_pdfData,
    };

    console.log("CAE Data auto-loaded to sharedRef:", sharedRef.currentCAE);
  };

  // ✅ Auto-load CAE data whenever calculation or globals change
  useEffect(() => {
    autoLoadCaeDataToSharedRef();
  }, [calculation, globalTDL, globalDE]);

  // -------------------------
  // 9️⃣ CLICK METHOD → TEMP + FINAL + sharedRef
  // -------------------------
  const generateAndSaveJson = () => {
    if (selectedVersion !== currentVersion) {
      alert("OLD VERSIONS CANNOT BE MODIFIED!");
      return;
    }

    const temp = buildTempJson();
    const final = buildFinalJson();

    alert("CAE SAVED!");

    console.log("CAE Save :- ", temp);
    handleSaveCae(temp);

    // Logic for Forge save  temo and final

    // Update sharedRef
    const iterationTotal =
      calculation.activities["ITERATIONS|ITERATIONS"]?.calculatedTotal || 0;

    // sharedRef.current = {
    //   globalTDL,
    //   globalDE,
    //   sumTDL: calculation.sumTDL,
    //   sumDE: calculation.sumDE,
    //   grandTotal: calculation.grand,
    //   activities: calculation.activities,
    //   tempJSON: JSON.stringify(temp, null, 2),
    //   finalJSON: JSON.stringify(final, null, 2),
    //   iterationTotal,
    // };
    //---Calculating the Phase1 and Phase2 for CAE enginer and CAE Standard Work---

    // Calculating Phase 1 & Phase 2 for CAE Engineers (TDL + Iteration)
    const CAEEngineersPhase1Value = (calculation?.sumTDL ?? 0) / 2;

    const CAEEngineersPhase2Value = (calculation?.sumTDL ?? 0) / 2;

    // Calculating Phase 1 & Phase 2 for CAE Standard Work
    const CAEStandardWorkPhase1Value =
      ((calculation?.sumDE ?? 0) + (iterationTotal ?? 0)) / 2;

    const CAEStandardWorkPhase2Value =
      ((calculation?.sumDE ?? 0) + (iterationTotal ?? 0)) / 2;

    // Generate PDF Data
    const finalContextData_pdfData = getCheckedActivities(temp);

    sharedRef.currentCAE = {
      globalTDL: globalTDL ?? 0,
      globalDE: globalDE ?? 0,

      sumTDL: calculation?.sumTDL ?? 0,
      sumDE: calculation?.sumDE ?? 0,
      grandTotal: calculation?.grand ?? 0,
      activities: calculation?.activities ?? [],

      tempJSON: JSON.stringify(temp ?? {}, null, 2),
      finalJSON: JSON.stringify(final ?? {}, null, 2),

      iterationTotal: iterationTotal ?? 0,

      CAEEngineersPhase1: CAEEngineersPhase1Value,
      CAEEngineersPhase2: CAEEngineersPhase2Value,

      CAEStandardWorkPhase1: CAEStandardWorkPhase1Value,
      CAEStandardWorkPhase2: CAEStandardWorkPhase2Value,

      pdfData: finalContextData_pdfData,
    };

    //alert(CAEEngineersPhase1Value +":"+ CAEEngineersPhase1Value  )
    //alert(CAEStandardWorkPhase1Value +":"+ CAEStandardWorkPhase1Value  )
    // console.log("SharedRef updated:", sharedRef.current);
  };

  //To apply shortcut Helper code start=========
  // step 1 :
  const applyShortcutForCustomer = (customerName, shortcutData, setData) => {
    console.log("Trying to apply Shortcut");

    setData((prev) => {
      const copy = structuredClone(prev);

      // 🔹 Try selected customer first
      let customerActivities =
        shortcutData?.CAE_SHORTCUT?.[customerName]?.Activity;

      // If not found → fallback to STANDARD
      if (!customerActivities) {
        console.log(
          `Customer "${customerName}" not found. Falling back to STANDARD`,
        );
        customerActivities = shortcutData?.CAE_SHORTCUT?.["STANDARD"]?.Activity;
      }

      if (!customerActivities) return prev;

      // OLD LOGIC (NOT WORKING for RT/HT/LT with 0)
      // Object.keys(copy.activities).forEach((activityKey) => {
      //   const parts = activityKey.split("|");
      //   const activityName = parts[1]?.trim();
      //   if (!activityName) return;

      //   const shortcutValue = customerActivities[activityName];

      //   // Apply only if Yes
      //   copy.activities[activityKey].checked = shortcutValue === "Yes";
      // });

      console.log("Customer Found");
      //new change:
      Object.keys(copy.activities).forEach((activityKey) => {
        const activity = copy.activities[activityKey];

        // Special case: ITERATIONS
        if (activityKey === "ITERATIONS|ITERATIONS") {
          // Keep ITERATIONS logic intact, e.g., noOfLoops stays as is
          activity.checked = customerActivities["ITERATIONS"] === "Yes";
          // Optionally, set default percentage or leave other ITERATION-specific fields
          return;
        }

        const parts = activityKey.split("|");
        const activityName = parts[1]?.trim();
        if (!activityName) return;

        const shortcutValue = customerActivities[activityName];

        // Set checked based on shortcut
        const isChecked = shortcutValue === "Yes";
        activity.checked = isChecked;

        // Set noOfLoops: 1 if checked, 0 if not
        activity.noOfLoops = isChecked ? 1 : 0;

        console.log("Shortcut Applied in each activity");
      });
      console.log("Shortcut Applied in CAE \n", JSON.stringify(copy));
      return copy;
    });
  };

  // Use effect called above

  // // step 1 :
  // useEffect(() => {
  //   const customer = "Audi"; //  hardcoded for now

  //   //todo1: Apply saved unsaved logic for forge .Short cut should  overide once saved CAE data

  //   applyShortcutForCustomer(customer, CAE_SHORTCUT, setData);
  // }, []);
  //To apply shortcut Helper code ends=========

  // -------------------------
  // 10️⃣ AUTO-GENERATE JSON for UI (readonly)
  // -------------------------
  const tempJSON = JSON.stringify(buildTempJson(), null, 2);
  const finalJSON = JSON.stringify(buildFinalJson(), null, 2);

  // -------------------------
  // 11️⃣ RETURN TO UI
  // -------------------------
  return {
    data,
    activities: calculation.activities,

    globalTDL,
    globalDE,
    setGlobalTDL,
    setGlobalDE,

    sumTDL: calculation.sumTDL,
    sumDE: calculation.sumDE,
    grandTotal: calculation.grand,

    updateActivity,
    generateAndSaveJson, // 🔘 click to update sharedRef

    tempJSON,
    finalJSON,
  };
}
