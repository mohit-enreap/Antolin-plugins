// hooks/useCalculations.js
export function useCalculations(activities, globalTDL, globalDE) {
  let sumTDL = 0;
  let sumDE = 0;
  let grand = 0;

  const result = JSON.parse(JSON.stringify(activities));

  Object.entries(result).forEach(([key, a]) => {
    if (key === "ITERATIONS|ITERATIONS") return;

    // 🛡️ Pre-define safe values to avoid NaN
    const proto = Number(a.proto ?? 0);
    const serie = Number(a.serie ?? 0);
    const loops = Number(a.noOfLoops ?? 1);
    const multiplier = proto + serie || 1; // Default to 1 if both are 0 to avoid zeroing out

    // 🔹 PREVIEW TOTAL
    a.previewTotal =
      (Number(a.TDL || 0) + Number(a.DE || 0) + Number(a.COO || 0)) *
      loops *
      multiplier;

    // 🔹 FINAL TOTAL logic
    const tdl = a.checked && loops > 0 ? Number(a.TDL || 0) * globalTDL : 0;
    const de = a.checked && loops > 0 ? Number(a.DE || 0) * globalDE : 0;
    const coo = a.checked && loops > 0 ? Number(a.COO || 0) : 0;

    const total = (tdl + de + coo) * loops * multiplier;
    a.calculatedTotal = total;

    // Update sums
    sumTDL += tdl * multiplier * loops;
    sumDE += de * multiplier * loops;
    grand += total;
  });

  // 🔁 ITERATION LOGIC
  const iter = result["ITERATIONS|ITERATIONS"];

  if (iter?.checked) {
    const iterDE = Object.entries(result)
      .filter(([k, a]) => a.checked && k !== "ITERATIONS|ITERATIONS")
      .reduce((s, [, a]) => {
        const m = Number(a.proto ?? 0) + Number(a.serie ?? 0) || 1;
        return s + Number(a.DE || 0) * globalDE * m;
      }, 0);

    iter.calculatedTotal =
      ((iterDE * Number(iter.percentage || 0)) / 100) *
      Number(iter.noOfLoops || 0);
    grand += iter.calculatedTotal;
  } else if (iter) {
    iter.calculatedTotal = 0;
  }

  return { activities: result, sumTDL, sumDE, grand };
}
