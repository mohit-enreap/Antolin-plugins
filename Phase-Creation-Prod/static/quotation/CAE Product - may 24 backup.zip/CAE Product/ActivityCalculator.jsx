import GlobalParams from "./components/GlobalParams";
import ActivityTable from "./components/ActivityTable";
import ActivityTableLessDetails from "./components/ActivityTableLessDetails";
import ResultTable from "./components/ResultTable";
import JSONViewer from "./components/JSONViewer";
import { useActivityLogic } from "./hooks/useActivityLogic";
import CAESummaryTable from "./components/CAESummaryTable";
import React, { useState } from "react";

// ✅ Import CAD hook with alias
import { useActivityLogic as useCADActivityLogic } from "../CAD Product/hooks/useActivityLogic";
function ActivityCalculator() {
  const logic = useActivityLogic();
  const iterationTotal =
    logic.activities["ITERATIONS|ITERATIONS"]?.calculatedTotal || 0;

  // ---- CAD logic (for quotation text only) ----
  const cadLogic = useCADActivityLogic();
  const quotationText = `Quotation: ${cadLogic.globalParams.product} ${cadLogic.globalParams.Customer} ${cadLogic.globalParams["ProjectName"]} ${cadLogic.globalParams["Type Of Development"]}`;
  const [showActivities, setShowActivities] = useState(false);
  return (
    <>
      <h1 style={{ color: "#0b74d1", marginBottom: 15 }}>{quotationText}</h1>
      <GlobalParams
        globalTDL={logic.globalTDL}
        globalDE={logic.globalDE}
        setGlobalTDL={logic.setGlobalTDL}
        setGlobalDE={logic.setGlobalDE}
      />

      <ActivityTableLessDetails
        activities={logic.activities}
        updateActivity={logic.updateActivity}
      />

      <button
        onClick={() => setShowActivities((prev) => !prev)}
        style={{ marginBottom: 10 }}
      >
        {showActivities ? "Hide Activities Details" : "Show Activities Details"}
      </button>

      {showActivities && (
        <ActivityTable
          activities={logic.activities}
          updateActivity={logic.updateActivity}
        />
      )}

      <ResultTable
        activities={logic.activities}
        sumTDL={logic.sumTDL}
        sumDE={logic.sumDE}
        grand={logic.grandTotal}
        globalTDL={logic.globalTDL}
        globalDE={logic.globalDE}
      />

      {/* ✅ Small summary table – NO extra logic */}
      <CAESummaryTable
        standard={logic.sumTDL}
        iteration={iterationTotal}
        engineers={logic.sumDE}
      />

      {/* <JSONViewer title="Temp JSON" json={logic.tempJSON} />
      <JSONViewer title="Final JSON" json={logic.finalJSON} /> */}
      {/* ---------------- Actions ---------------- */}
      {/*  // Logic for Forge save  temo and final on Click  */}
      <div style={{ marginTop: 12 }}>
        <button
          type="button"
          className="btn"
          onClick={logic.generateAndSaveJson}
        >
          ✅ Save CAE
        </button>
      </div>
      <p style={{ fontSize: "10px", color: "blue" }}>
        <span></span> CAE Data is auto refreshed
      </p>
      <div style={{ display: "flex", gap: "16px", marginTop: 16 }}>
        <div style={{ flex: 1 }}>
          <JSONViewer title="Temp JSON" json={logic.tempJSON} />
        </div>
        <div style={{ flex: 1 }}>
          <JSONViewer title="Final JSON" json={logic.finalJSON} />
        </div>
      </div>
    </>
  );
}

export default ActivityCalculator;
